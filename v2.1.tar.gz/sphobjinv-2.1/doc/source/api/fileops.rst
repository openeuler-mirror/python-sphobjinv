.. Module API page for fileops.py

sphobjinv.fileops
=================

.. automodule:: sphobjinv.fileops
    :members: