.. Module API page for re.py

sphobjinv.re
============

.. automodule:: sphobjinv.re
    :members: