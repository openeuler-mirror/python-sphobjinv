.. Module API page for inventory.py

sphobjinv.inventory
===================

.. automodule:: sphobjinv.inventory
    :members:

