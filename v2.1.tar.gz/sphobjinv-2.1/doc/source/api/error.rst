.. Module API page for error.py

sphobjinv.error
===============

.. automodule:: sphobjinv.error
    :members: