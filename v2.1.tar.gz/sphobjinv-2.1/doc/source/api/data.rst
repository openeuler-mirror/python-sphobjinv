.. Module API page for data.py

sphobjinv.data
==============

.. automodule:: sphobjinv.data
    :members: