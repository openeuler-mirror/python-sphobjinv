.. Module API page for schema.py

sphobjinv.schema
================

.. automodule:: sphobjinv.schema
    :members: