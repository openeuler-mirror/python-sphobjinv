.. Module API page for enum.py

sphobjinv.enum
==============

.. automodule:: sphobjinv.enum
    :members:
