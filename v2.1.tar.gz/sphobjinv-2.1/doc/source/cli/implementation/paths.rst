.. Module API page for cli/paths.py

sphobjinv.cli.paths
===================

.. automodule:: sphobjinv.cli.paths
    :members:

