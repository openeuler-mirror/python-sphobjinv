.. Module API page for CLI submodule code

sphobjinv.cli (non-API)
=======================

.. toctree::
    :maxdepth: 1

    core
    load
    parser
    paths
    ui
    write
    

.. .. |argparse| replace:: :mod:`argparse`