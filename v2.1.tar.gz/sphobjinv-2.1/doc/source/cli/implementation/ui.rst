.. Module API page for cli/ui.py

sphobjinv.cli.ui
================

.. automodule:: sphobjinv.cli.ui
    :members:

