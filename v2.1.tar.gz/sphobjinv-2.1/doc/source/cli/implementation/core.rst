.. Module API page for cli/core.py

sphobjinv.cli.core
==================

.. automodule:: sphobjinv.cli.core
    :members:

