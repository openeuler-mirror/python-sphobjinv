.. Module API page for cli/parser.py

sphobjinv.cli.parser
====================

.. automodule:: sphobjinv.cli.parser
    :members:

