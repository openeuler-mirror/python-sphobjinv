.. Module API page for cli/write.py

sphobjinv.cli.write
===================

.. automodule:: sphobjinv.cli.write
    :members:

